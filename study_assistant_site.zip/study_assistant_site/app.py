from flask import Flask, request
from openai import OpenAI
import os, json

app = Flask(__name__)
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

lesson_biology = '''درس: مدخل إلى علم الأحياء
علم الأحياء هو دراسة الحياة، ويهتم بدراسة أنواع الحياة وتاريخها وتركيب المخلوقات الحية وكيف تقوم بوظائفها وكيف تتفاعل مع بعضها ومع بيئتها.
تشترك المخلوقات الحية في خصائص الحياة: مكونة من خلية واحدة أو أكثر، إظهار التنظيم، النمو، التكاثر، الحاجة إلى الطاقة، الاستجابة للمثيرات، المحافظة على الاتزان الداخلي، والتكيف.'''

lesson_science = '''درس: طبيعة العلم وطرائقه
العلم الطبيعي هو بناء من المعرفة يعتمد على دراسة الطبيعة. البحث العلمي يعتمد على الملاحظة والتجربة. التفسير العلمي يعتمد على الأدلة. الفرضية تفسير قابل للاختبار. التجربة تستخدم لاختبار الفرضية وجمع البيانات. المجموعة الضابطة تستخدم للمقارنة، والمجموعة التجريبية تتعرض للعامل الذي يتم اختباره. المتغير المستقل هو العامل الذي يغيره الباحث، والمتغير التابع هو العامل الذي يتأثر به ويتم قياسه.'''

def lesson(name):
    return {"biology": lesson_biology, "science": lesson_science}.get(name, "")

@app.route("/", methods=["GET", "POST"])
def home():
    summary = ""
    questions = []
    selected = request.form.get("lesson", "biology")
    action = request.form.get("action", "")
    content = lesson(selected)

    if content and action == "summary":
        r = client.responses.create(model="gpt-5.6-luna", input="""اكتب ملخصًا تعليميًا واضحًا لطالب ثانوي. استخدم معلومات الدرس فقط، ولا تجعل الملخص مجرد قائمة مفردات. اشرح الأفكار والمفاهيم واربط بينها. رتبه إلى: الفكرة الرئيسية، شرح الدرس، أهم ما يجب تذكره.\n\n""" + content)
        summary = r.output_text
    elif content and action == "quiz":
        r = client.responses.create(model="gpt-5.6-luna", input="""أنشئ 10 أسئلة اختيار من متعدد من الدرس فقط. لكل سؤال 4 خيارات وإجابة صحيحة واحدة. أرجع JSON فقط بهذا الشكل: {\"questions\":[{\"question\":\"...\",\"options\":[\"...\",\"...\",\"...\",\"...\"],\"answer\":\"...\"}]} يجب أن تكون الإجابة الصحيحة موجودة حرفيًا ضمن الخيارات.\n\n""" + content)
        try: questions = json.loads(r.output_text).get("questions", [])
        except Exception: questions = []

    summary_html = f'''<section class="box"><h2>📚 ملخص الدرس</h2><div class="text">{summary}</div><form method="post"><input type="hidden" name="lesson" value="{selected}"><input type="hidden" name="action" value="quiz"><button>📝 ابدأ الاختبار</button></form></section>''' if summary else ""
    quiz_html = '<section class="box"><h2>📝 اختبار المراجعة</h2>'
    for i,q in enumerate(questions):
        quiz_html += f'<div class="question"><b>السؤال {i+1}</b><p>{q["question"]}</p>'
        for j,opt in enumerate(q["options"][:4]):
            quiz_html += f'<label><input type="radio" name="q{i}" value="{opt}" data-correct="{q["answer"]}"> {"أبجد"[j]}) {opt}</label>'
        quiz_html += f'<div id="r{i}" class="result"></div></div>'
    if questions:
        quiz_html += '''<button type="button" onclick="checkQuiz()">✅ صحّح إجاباتي</button><div id="final"></div><script>function checkQuiz(){let s=0,t=0;document.querySelectorAll('.question').forEach((c,i)=>{t++;let x=c.querySelector('input:checked'),f=c.querySelector('input'),r=document.getElementById('r'+i);if(!x){r.innerHTML='⚠️ لم تختر إجابة. الإجابة الصحيحة: '+f.dataset.correct;r.className='result wrong'}else if(x.value===f.dataset.correct){s++;r.textContent='✅ إجابة صحيحة!';r.className='result correct'}else{r.innerHTML='❌ إجابة غير صحيحة.<br>الإجابة الصحيحة: '+f.dataset.correct;r.className='result wrong'}});document.getElementById('final').innerHTML='<div class="final"><h2>🎯 نتيجتك</h2><strong>'+s+' / '+t+'</strong></div>'}</script></section>'''
    else: quiz_html = ""

    return f'''<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>مساعدي الدراسي</title><style>body{{margin:0;background:#f4f8f5;font-family:Arial;color:#333}}.container{{max-width:850px;margin:35px auto;padding:20px}}.card{{background:#fff;padding:38px;border-radius:24px;box-shadow:0 10px 30px #0001}}h1,h2{{color:#2e7d32;text-align:center}}h1{{font-size:40px}}.subtitle{{text-align:center;color:#777;font-size:19px}}select{{width:100%;padding:15px;border:1px solid #ddd;border-radius:12px;font-size:17px}}button{{display:block;margin:22px auto;padding:14px 30px;border:0;border-radius:12px;background:#2e7d32;color:#fff;font-size:18px;cursor:pointer}}.box{{margin-top:28px;padding:28px;background:#f0f7f0;border-radius:20px}}.text{{white-space:pre-line;line-height:2;font-size:18px}}.question{{background:#fff;padding:22px;margin:18px 0;border-radius:16px;border:1px solid #ddd}}.question p{{font-size:19px;font-weight:bold;line-height:1.8}}.question label{{display:block;padding:13px;margin:8px 0;background:#f7f7f7;border-radius:10px;cursor:pointer}}.result{{margin-top:12px;font-weight:bold;line-height:1.7}}.correct{{color:#2e7d32}}.wrong{{color:#c62828}}.final{{margin-top:25px;text-align:center;background:#fff;padding:22px;border-radius:16px}}.final strong{{font-size:38px;color:#2e7d32}}</style></head><body><div class="container"><div class="card"><h1>🎓 مساعدي الدراسي</h1><p class="subtitle">مساعدك الذكي لفهم الدروس ومراجعتها بطريقة سهلة</p><h2>📚 اختر الدرس الذي تريد مذاكرته</h2><form method="post"><select name="lesson"><option value="biology">مدخل إلى علم الأحياء</option><option value="science">طبيعة العلم وطرائقه</option></select><input type="hidden" name="action" value="summary"><button>🚀 ابدأ المذاكرة</button></form>{summary_html}{quiz_html}</div></div></body></html>'''

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
